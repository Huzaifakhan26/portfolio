import React, { useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faHtml5,
  faCss3Alt,
  faJs,
  faReact,
  faNode,
  faGitAlt,
  faJava,
} from "@fortawesome/free-brands-svg-icons";
import { faDatabase, faCode, faServer } from "@fortawesome/free-solid-svg-icons";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

function Skills() {
  useEffect(() => {
    // Different animations for each icon
    gsap.from(".html-icon", {
      opacity: 0,
      y: -50,
      duration: 4,
      ease: "bounce.out",
      scrollTrigger: { trigger: ".html-icon", start: "top 90%" },
    });
    gsap.from(".css-icon", {
      opacity: 0,
      x: -50,
      duration: 4,
      ease: "power2.out",
      scrollTrigger: { trigger: ".css-icon", start: "top 90%" },
    });
    gsap.from(".js-icon", {
      opacity: 0,
      y: 50,
      duration: 4,
      ease: "elastic.out(1, 0.3)",
      scrollTrigger: { trigger: ".js-icon", start: "top 90%" },
    });
    gsap.from(".react-icon", {
      opacity: 0,
      x: 50,
      duration: 4,
      ease: "power4.out",
      scrollTrigger: { trigger: ".react-icon", start: "top 90%" },
    });
    gsap.from(".node-icon", {
      opacity: 0,
      rotate: 360,
      duration: 4,
      ease: "back.out(2)",
      scrollTrigger: { trigger: ".node-icon", start: "top 90%" },
    });
    gsap.from(".mongo-icon", {
      opacity: 0,
      scale: 0.5,
      duration: 4,
      ease: "circ.out",
      scrollTrigger: { trigger: ".mongo-icon", start: "top 90%" },
    });
    gsap.from(".git-icon", {
      opacity: 0,
      y: -50,
      scale: 1.2,
      duration: 5,
      ease: "power3.out",
      scrollTrigger: { trigger: ".git-icon", start: "top 90%" },
    });
    gsap.from(".java-icon", {
      opacity: 0,
      x: -50,
      rotateY: 360,
      duration: 5,
      ease: "expo.out",
      scrollTrigger: { trigger: ".java-icon", start: "top 90%" },
    });
    gsap.from(".express-icon", {
      opacity: 0,
      y: 50,
      scale: 1.2,
      duration: 5,
      ease: "power2.out",
      scrollTrigger: { trigger: ".express-icon", start: "top 90%" },
    });
    gsap.from(".dsa-icon", {
      opacity: 0,
      rotate: 180,
      duration: 6,
      ease: "power4.out",
      scrollTrigger: { trigger: ".dsa-icon", start: "top 90%" },
    });
    gsap.from(".tailwind-icon", {
      opacity: 0,
      y: -50,
      scale: 0.8,
      duration: 2,
      ease: "power3.out",
      scrollTrigger: { trigger: ".tailwind-icon", start: "top 90%" },
    });
    gsap.from(".bootstrap-icon", {
      opacity: 0,
      scale: 1.5,
      duration: 6,
      ease: "power2.out",
      scrollTrigger: { trigger: ".bootstrap-icon", start: "top 90%" },
    });
  }, []);

  return (
    <div>
      {/* Technical Skills Section */}
      <section id="technical-skills" className="py-20 bg-gray-100">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-semibold text-center mb-12 text-gray-900">
            Technical Skills
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-8 justify-items-center">
            {[
              { icon: faHtml5, label: "HTML5", class: "html-icon" },
              { icon: faCss3Alt, label: "CSS3", class: "css-icon" },
              { icon: faJs, label: "JavaScript", class: "js-icon" },
              { icon: faReact, label: "React.js", class: "react-icon" },
              { icon: faNode, label: "Node.js", class: "node-icon" },
              { icon: faDatabase, label: "MongoDB", class: "mongo-icon" },
              { icon: faGitAlt, label: "GitHub", class: "git-icon" },
              { icon: faJava, label: "Java", class: "java-icon" },
              { icon: faServer, label: "Express.js", class: "express-icon" },
              { icon: faCode, label: "DSA", class: "dsa-icon" },
              { icon: faCss3Alt, label: "Tailwind CSS", class: "tailwind-icon" },
              { icon: faCss3Alt, label: "Bootstrap", class: "bootstrap-icon" },
            ].map((skill, index) => (
              <div
                key={index}
                className={`${skill.class} flex flex-col items-center`}
              >
                <div className="bg-white text-black p-4 rounded-full shadow-md flex items-center justify-center w-20 h-20 hover:border-4 hover:border-black hover:scale-110 transform transition duration-300">
                  <FontAwesomeIcon icon={skill.icon} size="2x" />
                </div>
                <p className="text-sm font-medium mt-2">{skill.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Skills;
