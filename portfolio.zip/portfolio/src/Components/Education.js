import React from 'react';
import rkdfLogo from "../Assets/RKDF.jpeg"; // Replace with the correct path to RKDF University logo
import Coding from "../Assets/CODING THINKER.png"; // Replace with the correct path to Coding Thinker logo
import MODELschool from "../Assets/MODEL.jpeg"; // Replace with the correct path to Model Higher Secondary School logo
import iperLogo from "../Assets/IPER.jpeg"; // Replace with the correct path to IPER College logo

function Education() {
  const educationData = [
    {
      institution: 'RKDF University',
      degree: 'Master of Computer Applications (MCA) Pursuing',
      year: '2024 - 2026',
      logo: rkdfLogo, // Add logo for RKDF University
    },

    {
      institution: 'Coding Thinker',
      degree: 'Java with DSA, MERN Stack',
      year: '2023 - 2024',
      logo: Coding, // Add logo for Coding Thinker
    },
    {
      institution: 'IPER College',
      degree: 'Bachelor of Business Administration (BBA) - Human Resources',
      year: '2021 - 2024',
      logo: iperLogo, // Add logo for IPER College
    },

    {
      institution: 'Model Higher Secondary School',
      degree: 'High School',
      year: '2020 - 2021',
      logo: MODELschool, // Add logo for Model Higher Secondary School
    },
  ];

  return (
    <section id="education" className="bg-gray-50 py-16 px-4 sm:px-8 lg:px-16 text-gray-800">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl sm:text-4xl font-bold text-center mb-12 text-gray-900">
          Education
        </h2>

        {/* Timeline Container */}
        <div className="relative border-l-4 border-gray-800">
          {educationData.map((edu, index) => (
            <div key={index} className="mb-8 pl-8 sm:pl-12 relative">
              {/* Timeline Dot */}
              <div className="absolute -left-[10px] sm:-left-4 top-2 w-5 h-5 bg-gray-800 rounded-full border-4 border-gray-50"></div>

              {/* Content */}
              <div className="flex items-center space-x-4">
                {/* Logo */}
                <img
                  src={edu.logo}
                  alt={`${edu.institution} Logo`}
                  className="w-16 h-16 sm:w-20 sm:h-20  object-fir grayscale" // Added grayscale
                />
                {/* Institution Details */}
                <div>
                  <h3 className="text-xl sm:text-2xl font-semibold mb-2">{edu.institution}</h3>
                  <p className="text-md sm:text-lg font-medium text-gray-600">{edu.degree}</p>
                  <p className="text-sm sm:text-md text-gray-500">{edu.year}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Education;
