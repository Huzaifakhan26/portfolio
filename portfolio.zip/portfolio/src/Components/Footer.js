import React from 'react';
import { FaLinkedin, FaGithub, FaWhatsapp, FaPhoneAlt, FaEnvelope } from 'react-icons/fa';

function Footer() {
  return (
    <footer className="bg-black text-white py-16 mt-12">
      <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center">
        {/* Footer Links */}
        <div className="flex flex-col md:flex-row items-center space-x-8 mb-8 md:mb-0">
          <div className="text-center md:text-left mb-6 md:mb-0">
            <h4 className="text-2xl font-semibold text-white">Huzaifa khan</h4>
            <p className="text-sm text-gray-400">Web developer, Designer,Team Coordinator,  Student </p>
          </div>

          {/* Social Links */}
          <div className="flex items-center space-x-6">
            <a
              href="https://www.linkedin.com/in/huzaifa-khan-223664220/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white text-3xl hover:text-gray-400 transition duration-300"
            >
              <FaLinkedin />
            </a>
            <a
              href="https://github.com/Huzaifakhan26"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white text-3xl hover:text-gray-400 transition duration-300"
            >
              <FaGithub />
            </a>
            <a
              href="https://wa.me/9685709015"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white text-3xl hover:text-gray-400 transition duration-300"
            >
              <FaWhatsapp />
            </a>
            <a
              href="tel:+91 9685709015"
              className="text-white text-3xl hover:text-gray-400 transition duration-300"
            >
              <FaPhoneAlt />
            </a>
            <a
              href="mailto:huzaifakhan262000@gmail.com"
              className="text-white text-3xl hover:text-gray-400 transition duration-300"
            >
              <FaEnvelope />
            </a>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="w-full border-t border-gray-700 pt-8 text-center">
          <p className="text-sm text-gray-400">
            © 2025 Huzaifa Khan. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
