import React, { useState } from 'react';
import './Navbar.css'; // Import the custom CSS file

function Navbar({
  homeRef,
  aboutRef,
  educationRef,
  projectsRef,
  skillsRef,
  contactRef,
  servicesRef,
  certificationsRef
}) {
  const [isOpen, setIsOpen] = useState(false);
//eslint-disable-next-line
  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  // Smooth scroll to the section using refs
  const scrollToSection = (sectionRef) => {
    sectionRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="navbar">
      <nav>
       
        <div className="menu">
          <ul>
            <li>
              <button onClick={() => scrollToSection(homeRef)}>Home</button>
            </li>
            <li>
              <button onClick={() => scrollToSection(aboutRef)}>About</button>
            </li>
            <li>
              <button onClick={() => scrollToSection(projectsRef)}>Projects</button>
            </li>
            <li>
              <button onClick={() => scrollToSection(educationRef)}>Education</button>
            </li>
            <li>
              <button onClick={() => scrollToSection(certificationsRef)}>Certifications</button>
            </li>
            <li>
              <button onClick={() => scrollToSection(skillsRef)}>Skills</button>
            </li>
            <li>
              <button onClick={() => scrollToSection(servicesRef)}>Services</button>
            </li>
            <li>
              <button onClick={() => scrollToSection(contactRef)}>Contact</button>
            </li>
          </ul>
        </div>
      </nav>
    </section>
  );
}

export default Navbar;
