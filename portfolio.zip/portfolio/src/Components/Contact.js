import React, { useState } from 'react';
import emailjs from 'emailjs-com'; // Import EmailJS library

function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [responseMessage, setResponseMessage] = useState('');
  const [showPopup, setShowPopup] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setResponseMessage('');

    try {
      // Send email using EmailJS
      const result = await emailjs.send(
        'service_i5xe33b', // Replace with your Service ID
        'template_51oqvie', // Replace with your Template ID
        {
          from_name: formData.name,
          from_email: formData.email,
          phone: formData.phone,
          message: formData.message,
        },
        'RAsJVJJKhjcBIHvko' // Replace with your Public Key
      );

      if (result.status === 200) {
        setResponseMessage('Message sent successfully!');
        setFormData({ name: '', email: '', phone: '', message: '' }); // Reset form
        setShowPopup(true); // Show success popup
      } else {
        setResponseMessage('Failed to send message. Please try again.');
      }
    } catch (error) {
      console.error('Error:', error);
      setResponseMessage('An error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const closePopup = () => {
    setShowPopup(false);
  };

  return (
    <section id="contact" className="py-20 bg-white min-h-screen flex justify-between">
      <div className="container mx-auto px-6 flex flex-col md:flex-row">
        {/* Contact Form */}
        <div className="max-w-md mx-auto bg-white text-black rounded-lg shadow-lg p-6 space-y-6 border-2 border-gray-500 md:w-2/3">
          <h2 className="text-3xl font-bold text-center mb-6 text-gray-900">Contact Me</h2>
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label className="block font-medium mb-1 text-black">Name</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full border-2 border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-gray-500 focus:border-gray-500 transition duration-300 hover:border-gray-400 active:border-gray-600"
                placeholder="Enter your name"
                required
              />
            </div>
            <div>
              <label className="block font-medium mb-1 text-black">Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full border-2 border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-gray-500 focus:border-gray-500 transition duration-300 hover:border-gray-400 active:border-gray-600"
                placeholder="Enter your email"
                required
              />
            </div>
            <div>
              <label className="block font-medium mb-1 text-black">Phone</label>
              <input
                type="text"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full border-2 border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-gray-500 focus:border-gray-500 transition duration-300 hover:border-gray-400 active:border-gray-600"
                placeholder="Enter your phone number"
                required
              />
            </div>
            <div>
              <label className="block font-medium mb-1 text-black">Message</label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                className="w-full border-2 border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-gray-500 focus:border-gray-500 transition duration-300 hover:border-gray-400 active:border-gray-600"
                rows="4"
                placeholder="Your message here..."
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-900 hover:scale-105 transition duration-300 active:bg-gray-800"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Sending...' : 'Send Message'}
            </button>
          </form>
          {/* Response Message */}
          {responseMessage && (
            <p className="mt-4 text-center text-sm text-gray-700">
              {responseMessage}
            </p>
          )}
        </div>
      </div>

      {/* Popup */}
      {showPopup && (
        <div className="fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg shadow-lg text-center">
            <h3 className="text-2xl font-bold mb-4">Thank You!</h3>
            <p className="mb-4">Thank you for contacting me. I will get back to you shortly.</p>
            <button
              onClick={closePopup}
              className="bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-900  transition duration-300"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </section>
  );
}

export default Contact;
