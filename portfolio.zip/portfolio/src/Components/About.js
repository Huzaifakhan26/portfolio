import React, { useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import photo from './profile.png'; // Replace with the correct path to your image

function About() {
  useEffect(() => {
    // Register ScrollTrigger plugin with GSAP
    gsap.registerPlugin(ScrollTrigger);

    // Animate About section on scroll
    gsap.fromTo(
      '.about-section',
      { opacity: 0, y: 50 },
      {
        opacity: 1,
        y: 0,
        duration: 1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: '.about-section',
          start: 'top 80%',
          end: 'top 20%',
          scrub: true,
          once: true,
        },
      }
    );
  }, []);

  return (
    <section
      id="about"
      className="py-20 px-4 bg-white flex justify-center items-center w-full"
    >
      <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center space-y-10 md:space-y-0 md:space-x-10 about-section">
        {/* Image Section */}
        <img
          src={photo}
          alt="Huzaifa Khan"
          className="rounded-full w-64 h-64 sm:w-72 sm:h-72 md:w-80 md:h-80 lg:w-96 lg:h-96 object-cover shadow-lg"
        />

        {/* Text Section */}
        <div className="text-gray-700 text-center md:text-left space-y-6">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900">
            About Me
          </h2>
          <p className="text-base sm:text-lg md:text-xl leading-relaxed">
            I'm a highly motivated full-stack developer with a strong background in creating innovative web applications using modern technologies.
          </p>
          <p className="text-base sm:text-lg md:text-xl leading-relaxed">
            I hold a Bachelor of Business Administration (BBA) degree and am currently pursuing a Master of Computer Applications (MCA). My primary interest lies in front-end development, where I excel in crafting responsive and visually appealing user interfaces.
          </p>
          <p className="text-base sm:text-lg md:text-xl leading-relaxed">
            I have a knack for rapid development and problem-solving, allowing me to deliver efficient and high-quality solutions for complex challenges. Whether working independently or collaborating with a team, I am committed to continuous learning and growth in the tech industry.
          </p>
          <a
          
            href="https://drive.google.com/drive/folders/1HDatMZ5FGpzDWbzJeuvpFAbMYqVzAv-5?usp=sharing" className="text-gray-600 font-semibold hover:underline text-lg"
          target='_blank' rel="noreferrer noopener"
          >
            Check out my resume
          </a>
        </div>
      </div>
    </section>
  );
}

export default About;
