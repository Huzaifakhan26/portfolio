import React from 'react';

const Projects = () => {
  return (
    <section id="projects" className="py-20 bg-black">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-white">
          Projects
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-8">
          {/* Project Card 1 */}
          <div className="bg-black border-2 border-gray-600 rounded-lg shadow-md p-4 sm:p-6 lg:p-8 transition-all transform hover:scale-105 hover:shadow-xl hover:shadow-gray-300/50 shadow-lg duration-700 ease-in-out">
            <h3 className="text-xl sm:text-2xl font-semibold mb-3 text-white">
              Portfolio Website
            </h3>
            <h6 className="text-gray-400 font-semibold mb-4">
              Technologies used:
              <p className="text-xs md:text-sm text-gray-300">React, GSAP, Tailwind CSS</p>
            </h6>
            <ul className="list-disc list-inside text-gray-300 mb-4 space-y-2">
              <li>Showcases personal projects, skills, and achievements.</li>
              <li>Modern animations using GSAP for an interactive experience.</li>
              <li>Responsive design ensuring seamless viewing across devices.</li>
              <li>Includes a contact form with email functionality.</li>
            </ul>
            <a
              href="https://github.com/Huzaifakhan26/Portfolio.git"
              className="text-gray-50 font-semibold hover:underline"
              target="_blank"
              rel="noreferrer noopener"
            >
              View Project
            </a>
          </div>

          {/* Project Card 2 */}
          <div className="bg-black border-2 border-gray-600 rounded-lg shadow-md p-4 sm:p-6 lg:p-8 transition-all transform hover:scale-105 hover:shadow-xl hover:shadow-gray-300/50 shadow-lg duration-700 ease-in-out">
            <h3 className="text-xl sm:text-2xl font-semibold mb-3 text-white">
              E-commerce Platform
            </h3>
            <h6 className="text-gray-400 font-semibold mb-4">
              Technologies used:
              <p className="text-xs md:text-sm text-gray-300">HTML, CSS, JavaScript, Tailwind CSS</p>
            </h6>
            <ul className="list-disc list-inside text-gray-300 mb-4 space-y-2">
              <li>Dynamic product search with filtering and sorting options.</li>
              <li>Integrated cart functionality and secure payment gateway.</li>
              <li>User authentication with role-based access control.</li>
              <li>Admin dashboard for inventory and order management.</li>
            </ul>
            <a
              href="https://buyzaar.netlify.app/"
              className="text-gray-50 font-semibold hover:underline"
              target="_blank"
              rel="noreferrer noopener"
            >
              View Project
            </a>
          </div>

          {/* Project Card 3 */}
          <div className="bg-black border-2 border-gray-600 rounded-lg shadow-md p-4 sm:p-6 lg:p-8 transition-all transform hover:scale-105 hover:shadow-xl hover:shadow-gray-300/50 shadow-lg duration-700 ease-in-out">
            <h3 className="text-xl sm:text-2xl font-semibold mb-3 text-white">
              Tour and Travels
            </h3>
            <h6 className="text-gray-400 font-semibold mb-4">
              Technologies used:
              <p className="text-xs md:text-sm text-gray-300">React, Tailwind CSS, GSAP, SMTP</p>
            </h6>
            <ul className="list-disc list-inside text-gray-300 mb-4 space-y-2">
              <li>Comprehensive booking system for international/domestic tours.</li>
              <li>Interactive package comparison for better decision-making.</li>
              <li>Dynamic forms to collect user preferences and travel details.</li>
              <li>Email integration for booking confirmations and updates.</li>
            </ul>
            <a
              href="https://github.com/Huzaifakhan26/Lucky-Paradise-tour-and-travels-.git"
              className="text-gray-50 font-semibold hover:underline"
              target="_blank"
              rel="noreferrer noopener"
            >
              View Project
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;
