import React, { useEffect } from "react";

const Services = () => {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-card");
          }
        });
      },
      { threshold: 0.5 }
    );

    const cards = document.querySelectorAll(".service-card");
    cards.forEach((card) => observer.observe(card));

    return () => observer.disconnect();
  }, []);

  return (
    <section id="services" className="py-20 bg-black">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-white">
          Services
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {/* Service Card 1 */}
          <div className="service-card bg-black border-2 border-gray-600 rounded-lg shadow-md p-6 lg:p-8 transition-all transform hover:scale-105 hover:shadow-xl hover:shadow-gray-300/50 duration-700 ease-in-out">
            <h3 className="text-2xl font-semibold mb-3 text-white">
              Website Development
            </h3>
            <ul className="list-disc list-inside text-gray-300 mb-4 space-y-2">
              <li>Responsive and mobile-friendly designs.</li>
              <li>SEO-optimized for better search visibility.</li>
              <li>Modern frameworks like React and Tailwind CSS.</li>
              <li>Cross-browser compatibility.</li>
              <li>Fast loading and user-friendly interface.</li>
            </ul>
          </div>

          {/* Service Card 2 */}
          <div className="service-card bg-black border-2 border-gray-600 rounded-lg shadow-md p-6 lg:p-8 transition-all transform hover:scale-105 hover:shadow-xl hover:shadow-gray-300/50 duration-700 ease-in-out">
            <h3 className="text-2xl font-semibold mb-3 text-white">
              Web Application Development
            </h3>
            <ul className="list-disc list-inside text-gray-300 mb-4 space-y-2">
              <li>Dynamic and interactive web apps using React.</li>
              <li>High performance and scalability.</li>
              <li>Real-time data synchronization.</li>
              <li>Secure user authentication.</li>
              <li>Custom features tailored to your needs.</li>
            </ul>
          </div>

          {/* Service Card 3 */}
          <div className="service-card bg-black border-2 border-gray-600 rounded-lg shadow-md p-6 lg:p-8 transition-all transform hover:scale-105 hover:shadow-xl hover:shadow-gray-300/50 duration-700 ease-in-out">
            <h3 className="text-2xl font-semibold mb-3 text-white">
              Custom Software Solutions
            </h3>
            <ul className="list-disc list-inside text-gray-300 mb-4 space-y-2">
              <li>End-to-end tailored development.</li>
              <li>Robust backend for reliability.</li>
              <li>Flexible and adaptive strategies.</li>
              <li>Scalable architecture for growth.</li>
              <li>Support and updates post-launch.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
