import React from 'react';

const Certifications = () => {
  const handleViewCertificate = (url) => {
    window.open(url, "_blank");
  };

  return (
    <section id="certifications" className="py-20 bg-black">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-bold text-center mb-12 text-white">
          Certifications
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Certification Card 1: Java Basics from HackerRank */}
          <div className="bg-black border-2 border-gray-600 rounded-lg shadow-md p-6 lg:p-8 transition-all transform hover:scale-105 hover:shadow-xl hover:shadow-gray-300/50 shadow-lg duration-700 ease-in-out">
            <h3 className="text-2xl font-semibold mb-3 text-white">
              Java Basics - HackerRank
            </h3>
            <h6 className="text-gray-400 font-semibold mb-4">
              Issued by:
              <p className="text-xs text-gray-300">HackerRank</p>
            </h6>
            <ul className="list-disc list-inside text-gray-300 mb-4 space-y-2">
              <li>Completed a certification in Java Basics from HackerRank.</li>
              <li>Covered topics like basic Java syntax, loops, conditionals, and arrays.</li>
            </ul>
            <button
              onClick={() =>
                handleViewCertificate(
                  'https://drive.google.com/file/d/1X8JgG7r_QfWfGk4Z7sIgaVUrGDLxczaJ/view'
                )
              }
              className="bg-black text-white font-semibold py-2 px-4 rounded-lg block w-full text-center transition duration-300 hover:bg-gray-800"
            >
              View Certificate
            </button>
          </div>

          {/* Certification Card 2: OOPS in Java from Simplilearn */}
          <div className="bg-black border-2 border-gray-600 rounded-lg shadow-md p-6 lg:p-8 transition-all transform hover:scale-105 hover:shadow-xl hover:shadow-gray-300/50 shadow-lg duration-700 ease-in-out">
            <h3 className="text-2xl font-semibold mb-3 text-white">
              OOPS in Java - Simplilearn
            </h3>
            <h6 className="text-gray-400 font-semibold mb-4">
              Issued by:
              <p className="text-xs text-gray-300">Simplilearn</p>
            </h6>
            <ul className="list-disc list-inside text-gray-300 mb-4 space-y-2">
              <li>Completed a certification in OOPS Concepts in Java from Simplilearn.</li>
              <li>Covered topics like Object-Oriented Programming (OOP), classes, objects, inheritance, polymorphism, and encapsulation.</li>
            </ul>
            <button
              onClick={() =>
                handleViewCertificate(
                  'https://drive.google.com/file/d/1X95zq5LK7tXrAB4wynpGav3nha9RsaDq/view'
                )
              }
              className="bg-black text-white font-semibold py-2 px-4 rounded-lg block w-full text-center transition duration-300 hover:bg-gray-800"
            >
              View Certificate
            </button>
          </div>

          {/* Certification Card 3: Java DSA and MERN Stack from Coding Thinker */}
          <div className="bg-black border-2 border-gray-600 rounded-lg shadow-md p-6 lg:p-8 transition-all transform hover:scale-105 hover:shadow-xl hover:shadow-gray-300/50 shadow-lg duration-700 ease-in-out">
            <h3 className="text-2xl font-semibold mb-3 text-white">
              Java DSA & MERN Stack - Coding Thinker
            </h3>
            <h6 className="text-gray-400 font-semibold mb-4">
              Issued by:
              <p className="text-xs text-gray-300">Coding Thinker</p>
            </h6>
            <ul className="list-disc list-inside text-gray-300 mb-4 space-y-2">
              <li>Completed certifications in Java DSA and MERN Stack from Coding Thinker.</li>
              <li>Covered topics like Data Structures and Algorithms in Java, along with full-stack MERN development.</li>
            </ul>
         
          </div>
        </div>
      </div>
    </section>
  );
};

export default Certifications;
