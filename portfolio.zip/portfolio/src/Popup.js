import { useState, useEffect } from 'react';

function WelcomePopup() {
  const [isOpen, setIsOpen] = useState(true); // Popup starts open
  const [isClosing, setIsClosing] = useState(false); // Track if the popup is closing

  // Auto-close the popup after 4 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsClosing(true); // Trigger collapse animation after 4 seconds
      setTimeout(() => setIsOpen(false), 700); // Close after the collapse animation (700ms)
    }, 4000);

    return () => clearTimeout(timer); // Clear the timer when the component unmounts
  }, []);

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-10 z-50">
          <div
            className={`bg-white p-6 rounded-lg shadow-lg max-w-sm w-full overflow-hidden transition-all duration-700 ease-in-out ${
              isClosing ? 'max-h-0 opacity-0' : 'max-h-screen opacity-100'
            }`}
          >
            <div className="text-center">
              <h2 className="text-xl font-semibold text-black mb-4">
                Welcome to the portfolio of 
              </h2>
              <br></br>
              <h3 className="text-xl font-semibold text-black mb-4">
                Huzaifa khan 
              </h3>
              
              <p className="text-sm text-gray-600 mb-6">
                Let’s build something amazing together. Your journey to innovative digital solutions begins here!
              </p>
             
              <button
                onClick={() => {
                  setIsClosing(true);
                  setTimeout(() => setIsOpen(false), 700); // Close after animation (700ms)
                }}
                className="bg-black text-white px-4 py-2 rounded-md hover:bg-Gray-600 transition duration-300"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default WelcomePopup;
