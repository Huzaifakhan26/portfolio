import React, { useRef } from 'react';
import Navbar from './Components/Navbar';
import About from './Components/About';
import Projects from './Components/Projects';
import Skills from './Components/Skills';
import Services from './Components/Services';
import Contact from './Components/Contact';
import Hero from './Components/Hero';
import Footer from './Components/Footer';
import Popup from './Popup';
import Education from './Components/Education';
import Certifications from './Components/Certifications';

function App() {
  const homeRef = useRef(null);
  const aboutRef = useRef(null);
  const projectsRef = useRef(null);
  const skillsRef = useRef(null);
  const contactRef = useRef(null);
  const servicesRef = useRef(null);  // Added servicesRef
  const educationRef = useRef(null); // Added educationRef
  const certificationsRef = useRef(null); // Added certificationsRef

  return (
    <div>
      <Navbar
        homeRef={homeRef}
        aboutRef={aboutRef}
        projectsRef={projectsRef}
        skillsRef={skillsRef}
        contactRef={contactRef}
        servicesRef={servicesRef}
        educationRef={educationRef}  // Pass educationRef to Navbar
        certificationsRef={certificationsRef}  // Pass certificationsRef to Navbar
      />
      <Popup /> {/* Popup component */}

      {/* Sections with ref for smooth scroll */}
      <div ref={homeRef} id="home">
        <Hero /> {/* Hero section content */}
      </div>
      <div ref={aboutRef} id="about">
        <About /> {/* About section content */}
      </div>
      <div ref={projectsRef} id="projects">
        <Projects /> {/* Projects section content */}
      </div>
   
      <div ref={educationRef} id="education">
        <Education /> {/* Education section content */}
      </div>

      <div ref={certificationsRef} id="certifications">
        <Certifications /> {/* Certifications section content */}
      </div>

   

      <div ref={skillsRef} id="skills">
        <Skills /> {/* Skills section content */}
      </div>



      <div ref={servicesRef} id="services">
        <Services /> {/* Services section content */}
      </div>


      <div ref={contactRef} id="contact">
        <Contact /> {/* Contact section content */}
      </div>





      <Footer /> {/* Footer section */}
    </div>
  );
}

export default App;
